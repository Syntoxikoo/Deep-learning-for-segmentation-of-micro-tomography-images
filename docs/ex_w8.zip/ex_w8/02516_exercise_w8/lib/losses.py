import torch
import torch.nn as nn
import numpy as np

class BCELoss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, y_pred, y_true):
        loss = torch.mean(y_pred - y_true*y_pred + torch.log(1 + torch.exp(-y_pred)))
        return loss

class DiceLoss(nn.Module):
    def __init__(self):
        super().__init__()
    
    def dice_score(self, pred_mask, true_mask, eps=1e-6):
        # pred_mask = torch.sigmoid(pred_mask) # convert logits to prob

        # # flatten tensors
        # pred_mask = pred_mask.contiguous().view(-1)
        # true_mask = true_mask.contiguous().view(-1)
        
        
        # both are binaries (0/1) or probabilities in [0,1]
        intersection = (pred_mask * true_mask).sum()
        union = pred_mask.sum() + true_mask.sum()
        return (2 * intersection + eps) / (union + eps)

    def forward(self, y_pred, y_true):
        print(y_true.min(), y_true.max())
        print(y_pred.min(), y_pred.max())
        print(y_pred.shape)
        print(y_true.shape)
        dice = self.dice_score(y_pred, y_true)
        return 1 - dice  # loss = 1 - score


class FocalLoss(nn.Module):
    def __init__(self, gamma=2, reduction='mean'):
        super().__init__()
        self.gamma = gamma
        self.reduction = reduction


    def forward(self, y_pred, y_true):
         # Compute probabilities with sigmoid
        p = torch.sigmoid(y_pred)

        # Clamp to avoid log(0)
        p = p.clamp(min=1e-6, max=1-1e-6)


        # Focal loss formula
        loss = - (y_true * (1 - p)**self.gamma * torch.log(p) +
                  (1 - y_true) * p**self.gamma * torch.log(1 - p))

        # Reduce to scalar
        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:
            return loss  # return unreduced

class BCELoss_TotalVariation(nn.Module):
    def __init__(self, alpha_center=0.1, alpha_sparsity=0.1, alpha_tv=0.1):
        """
        alpha_center : weight for centeredness regularization
        alpha_sparsity : weight for sparsity regularization
        alpha_tv : weight for total variation (contiguity)
        """
        super().__init__()
        self.alpha_center = alpha_center
        self.alpha_sparsity = alpha_sparsity
        self.alpha_tv = alpha_tv

    def forward(self, y_pred, y_true):
        loss = torch.mean(y_pred - y_true*y_pred + torch.log(1 + torch.exp(-y_pred)))
         # Apply sigmoid to get probabilities
        probs = torch.sigmoid(y_pred)
        
        # ---- Centeredness ----
        # Assume y_pred shape: (B, 1, H, W)
        B, C, H, W = probs.shape
        cy, cx = H // 2, W // 2
        center_val = probs[:, 0, cy, cx]  # predicted probability at center
        L_centered = 1 - center_val.mean()  # punishes if segmentation not centered

        # ---- Sparsity ----
        L_sparsity = probs.mean()  # encourages small/compact segmentation

        # ---- Contiguity / Total Variation ----
        tv_h = torch.abs(probs[:, :, 1:, :] - probs[:, :, :-1, :]).sum()
        tv_w = torch.abs(probs[:, :, :, 1:] - probs[:, :, :, :-1]).sum()
        L_contiguity = (tv_h + tv_w) / B  # normalize by batch size

        # ---- Total regularization ----
        regularization = (self.alpha_center * L_centered +
                          self.alpha_sparsity * L_sparsity +
                          self.alpha_tv * L_contiguity)

        return loss + regularization

