import torch
import torch.nn as nn
import torch.nn.functional as F

class UNet(nn.Module):
    def __init__(self):
        super().__init__()

        # encoder (downsampling)
        self.enc_conv0 = nn.Conv2d(3, 64, 3, padding=1)
        self.pool0 = nn.MaxPool2d(2, 2)  # 128 -> 64
        self.enc_conv1 = nn.Conv2d(64, 64, 3, padding=1)
        self.pool1 = nn.MaxPool2d(2, 2)  # 64 -> 32
        self.enc_conv2 = nn.Conv2d(64, 64, 3, padding=1)
        self.pool2 = nn.MaxPool2d(2, 2)  # 32 -> 16
        self.enc_conv3 = nn.Conv2d(64, 64, 3, padding=1)
        self.pool3 = nn.MaxPool2d(2, 2)  # 16 -> 8

        # bottleneck
        self.bottleneck_conv = nn.Conv2d(64, 64, 3, padding=1)

        # decoder (upsampling)
        self.upsample = nn.Upsample(scale_factor=2, mode='nearest')  # use the same instance

        self.dec_conv0 = nn.Conv2d(128, 64, 3, padding=1)
        self.dec_conv1 = nn.Conv2d(128, 64, 3, padding=1)
        self.dec_conv2 = nn.Conv2d(128, 64, 3, padding=1)
        self.dec_conv3 = nn.Conv2d(64, 1, 3, padding=1)

    def forward(self, x):
        # encoder
        e0 = self.pool0(F.relu(self.enc_conv0(x)))
        e1 = self.pool1(F.relu(self.enc_conv1(e0)))
        e2 = self.pool2(F.relu(self.enc_conv2(e1)))
        e3 = self.pool3(F.relu(self.enc_conv3(e2)))

        # bottleneck
        b = F.relu(self.bottleneck_conv(e3))

        # decoder + skip connections
        u0 = self.upsample(b)

        # concat with encoder feature map at same spatial size (e2) == skip connection
        d0_in = torch.cat([u0, e2], dim=1)   # channels: 64 + 64 = 128
        d0 = F.relu(self.dec_conv0(d0_in))   # -> 64 channels, spatial 16

        u1 = self.upsample(d0)
        d1_in = torch.cat([u1, e1], dim=1)   # channels: 64 + 64 = 128
        d1 = F.relu(self.dec_conv1(d1_in))   # -> 64 channels, spatial 32

        u2 = self.upsample(d1)
        d2_in = torch.cat([u2, e0], dim=1)   # channels: 64 + 64 = 128
        d2 = F.relu(self.dec_conv2(d2_in))   # -> 64 channels, spatial 64

        u3 = self.upsample(d2)
        out = self.dec_conv3(u3)
        return out

class UNet2(nn.Module):
    def __init__(self):
        super().__init__()

        # ---------- Encoder (Conv stride=2 replaces MaxPool) ----------
        self.enc_conv0 = nn.Conv2d(3, 64, 3, padding=1)       # input 3ch -> 64
        self.down0 = nn.Conv2d(64, 64, 3, stride=2, padding=1)  # 128 -> 64
        
        self.enc_conv1 = nn.Conv2d(64, 64, 3, padding=1)
        self.down1 = nn.Conv2d(64, 64, 3, stride=2, padding=1)  # 64 -> 32
        
        self.enc_conv2 = nn.Conv2d(64, 64, 3, padding=1)
        self.down2 = nn.Conv2d(64, 64, 3, stride=2, padding=1)  # 32 -> 16
        
        self.enc_conv3 = nn.Conv2d(64, 64, 3, padding=1)
        self.down3 = nn.Conv2d(64, 64, 3, stride=2, padding=1)  # 16 -> 8
        
        # ---------- Bottleneck ----------
        self.bottleneck = nn.Conv2d(64, 64, 3, padding=1)

        # ---------- Decoder (Transpose Conv replaces upsample) ----------
        # Each decode conv takes (skip + decode) = 64 + 64 = 128 ch
        self.up0 = nn.ConvTranspose2d(64, 64, 2, stride=2)  # 8 -> 16
        self.dec_conv0 = nn.Conv2d(128, 64, 3, padding=1)

        self.up1 = nn.ConvTranspose2d(64, 64, 2, stride=2)  # 16 -> 32
        self.dec_conv1 = nn.Conv2d(128, 64, 3, padding=1)

        self.up2 = nn.ConvTranspose2d(64, 64, 2, stride=2)  # 32 -> 64
        self.dec_conv2 = nn.Conv2d(128, 64, 3, padding=1)

        self.up3 = nn.ConvTranspose2d(64, 64, 2, stride=2)  # 64 -> 128
        self.dec_conv3 = nn.Conv2d(128, 1, 3, padding=1)


    def forward(self, x):
        # ----- Encoder -----
        e0 = F.relu(self.enc_conv0(x))     # 128
        p0 = F.relu(self.down0(e0))        # 64

        e1 = F.relu(self.enc_conv1(p0))    # 64
        p1 = F.relu(self.down1(e1))        # 32

        e2 = F.relu(self.enc_conv2(p1))    # 32
        p2 = F.relu(self.down2(e2))        # 16

        e3 = F.relu(self.enc_conv3(p2))    # 16
        p3 = F.relu(self.down3(e3))        # 8

        # ----- Bottleneck -----
        b = F.relu(self.bottleneck(p3))

        # ----- Decoder w/ Correct Skip Connections -----
        u0 = self.up0(b)                            # 8 -> 16
        d0 = F.relu(self.dec_conv0(torch.cat([u0, e3], dim=1)))

        u1 = self.up1(d0)                           # 16 -> 32
        d1 = F.relu(self.dec_conv1(torch.cat([u1, e2], dim=1)))

        u2 = self.up2(d1)                           # 32 -> 64
        d2 = F.relu(self.dec_conv2(torch.cat([u2, e1], dim=1)))

        u3 = self.up3(d2)                           # 64 -> 128
        out = self.dec_conv3(torch.cat([u3, e0], dim=1))  # concat with e0 here

        return out


# quick sanity check
if __name__ == "__main__":
    model = UNet()
    x = torch.randn(2, 3, 128, 128)  # batch 2 RGB 128x128
    y = model(x)
    print("output shape:", y.shape)  # should be (2, 1, 128, 128)
