import torch
import torch.nn as nn
import torch.nn.functional as F

class DilatedNet(nn.Module):
    def __init__(self, in_channels=3, base_channels=64, num_layers=5):
        super().__init__()

        dilation_rates = [2**i for i in range(num_layers)]   # [1,2,4,8,16,...]

        layers = []
        prev_channels = in_channels

        for d in dilation_rates:
            layers.append(
                nn.Conv2d(
                    prev_channels,
                    base_channels,
                    kernel_size=3,
                    padding=d,   # keep dimensions
                    dilation=d
                )
            )
            prev_channels = base_channels

        # Register dilated conv layers
        self.dilated_blocks = nn.ModuleList(layers)

        # Final 1-channel output (for segmentation)
        self.final_conv = nn.Conv2d(base_channels, 1, kernel_size=1)

    def forward(self, x):
        out = x
        for conv in self.dilated_blocks:
            out = F.relu(conv(out))
        out = self.final_conv(out)  # no activation (use BCEWithLogitsLoss externally)
        return out


# ---- Quick sanity check ----
if __name__ == "__main__":
    model = DilatedNet()
    x = torch.randn(1, 3, 128, 128)
    y = model(x)
    print("Output shape:", y.shape)   # expected [1,1,128,128]
