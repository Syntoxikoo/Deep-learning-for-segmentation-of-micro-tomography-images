import os
import numpy as np
import glob
import PIL.Image as Image

# pip install torchsummary
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.datasets as datasets
from torch.utils.data import DataLoader, random_split
import torchvision.transforms as transforms
from torchvision import models
from torchsummary import summary
import torch.optim as optim
from time import time
from lib.model.EncDecModel import EncDec
from lib.model.DilatedNetModel import DilatedNet
from lib.model.UNetModel import UNet, UNet2
from lib.losses import BCELoss, DiceLoss, FocalLoss, BCELoss_TotalVariation
#  
from lib.dataset.PhCDataset import PhC

size = 128
batch_size = 6
learning_rate = 1e-3
epochs = 20
val_fraction = 0.1
save_path = 'saved_models'
save_name = 'encdec_state.pth'
os.makedirs(save_path, exist_ok=True)
save_filepath = os.path.join(save_path, save_name)

# Transforms
train_transform = transforms.Compose([transforms.Resize((size, size)),
                                    transforms.ToTensor()])
test_transform = transforms.Compose([transforms.Resize((size, size)),
                                    transforms.ToTensor()])

# Dataset
full_trainset = PhC(train=True, transform=train_transform)

# IMPORTANT NOTE: There is no validation set provided here, but don't forget to
# have one for the project
# create a small validation split since none was provided
val_size = int(len(full_trainset) * val_fraction)
train_size = len(full_trainset) - val_size
trainset, valset = random_split(full_trainset, [train_size, val_size])

train_loader = DataLoader(trainset, batch_size=batch_size, shuffle=True,
                          num_workers=3)
testset = PhC(train=False, transform=test_transform)
test_loader = DataLoader(testset, batch_size=batch_size, shuffle=False,
                          num_workers=3)
val_loader = DataLoader(valset, batch_size=batch_size, shuffle=False, num_workers=3)


print(f"Loaded {len(trainset)} training images, {len(valset)} validation images")
print(f"Loaded {len(testset)} test images")

# Training setup
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print("Using device:", device)

# model = EncDec().to(device)
# model = UNet().to(device) # TODO
# model = UNet2().to(device) # TODO
model = DilatedNet().to(device) # TODO
#summary(model, (3, 256, 256))

opt = optim.Adam(model.parameters(), learning_rate)

# loss_fn = BCELoss()
# loss_fn = DiceLoss() # TODO
loss_fn = FocalLoss() # TODO
# loss_fn = BCELoss_TotalVariation() # TODO

# Training loop
X_test, Y_test = next(iter(test_loader))
model.train()  # train mode
for epoch in range(epochs):
    tic = time()
    print(f'* Epoch {epoch+1}/{epochs}')

    avg_loss = 0
    for X_batch, y_true in train_loader:
        X_batch = X_batch.to(device)
        y_true = y_true.to(device)

        # set parameter gradients to zero
        opt.zero_grad()

        # forward
        y_pred = model(X_batch)
        # IMPORTANT NOTE: Check whether y_pred is normalized or unnormalized
        # and whether it makes sense to apply sigmoid or softmax.
        loss = loss_fn(y_pred, y_true)  # forward-pass
        loss.backward()  # backward-pass
        opt.step()  # update weights

        # calculate metrics to show the user
        avg_loss += loss / len(train_loader)

    # IMPORTANT NOTE: It is a good practice to check performance on a
    # validation set after each epoch.
    #model.eval()  # testing mode
    #Y_hat = F.sigmoid(model(X_test.to(device))).detach().cpu()
    print(f' - loss: {avg_loss}')

# Save the model
torch.save(model, save_filepath)
print("Training has finished!")
