#!/bin/bash
# ===========================================
# Script to run training for the EncDec auto-encoder
# ===========================================

#BSUB -J EncDecTrain
#BSUB -W 2:00
#BSUB -n 4
#BSUB -R "rusage[mem=4096]"
#BSUB -R "span[hosts=1]"         # All cores on one node
#BSUB -oo encdec_train_%J.out

set -e

# Exit immediately if a command fails
set -e

# ---------- CONFIG ----------
# Path to your dataset (update if needed)
DATA_PATH="/dtu/datasets1/02516/phc_data"

# Python environment (if using conda/venv)
# source ~/miniconda3/etc/profile.d/conda.sh
# conda activate myenv
# Activate virtual environment
source ~/venvs/phc_env/bin/activate

# Directory to save trained models
SAVE_DIR="saved_models"

# Training parameters
EPOCHS=20
LR=0.001
BATCH_SIZE=6

# ---------- EXECUTION ----------
echo "==========================================="
echo "Starting training for EncDec Autoencoder"
echo "Dataset: $DATA_PATH"
echo "Saving models to: $SAVE_DIR"
echo "Epochs: $EPOCHS | LR: $LR | Batch size: $BATCH_SIZE"
echo "==========================================="

# Export dataset path for PhCDataset.py
export PHC_DATA_PATH="$DATA_PATH"

# Create save directory if not exists
mkdir -p "$SAVE_DIR"

# Run training
python3 train.py --epochs "$EPOCHS" --lr "$LR" --batch_size "$BATCH_SIZE" --save_dir "$SAVE_DIR"

echo "==========================================="
echo "Training completed successfully!"
echo "Model saved under $SAVE_DIR"
echo "==========================================="
