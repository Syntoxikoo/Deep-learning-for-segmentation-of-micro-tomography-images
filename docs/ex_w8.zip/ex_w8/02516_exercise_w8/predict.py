# imports the model architecture
# loads the saved weights: Use torch.load function
# loads the test set of a DatasetLoader (see train.py)
# Iterate over the test set images, generate predictions, save segmentation masks

# predict.py
import os
import torch
import numpy as np
from PIL import Image
from torchvision import transforms
from lib.model.EncDecModel import EncDec
from lib.dataset.PhCDataset import PhC

def save_mask(array, path):
    # array expected binary 2D array (0/1)
    # array should be a 2D numpy array with 0s and 1s
    # np.unique(array) == [0, 1]
    # len(np.shape(array)) == 2
    im_arr = (array * 255).astype(np.uint8)
    Image.fromarray(im_arr).save(path)

def main(model_path='saved_models/encdec_state.pth',
         output_dir='predictions',
         size=128,
         threshold=0.5,
         device=None):
    device = device or (torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu'))
    os.makedirs(output_dir, exist_ok=True)

    # prepare model
    model = EncDec().to(device)
    state = torch.load(model_path, map_location=device)
    model.load_state_dict(state)
    model.eval()

    # test dataset (same transforms as training)
    transform = transforms.Compose([transforms.Resize((size, size)),
                                    transforms.ToTensor()])
    testset = PhC(train=False, transform=transform)
    dataloader = torch.utils.data.DataLoader(testset, batch_size=1, shuffle=False)

    # We'll use the original filenames to save corresponding predictions
    for idx, (X, Y) in enumerate(dataloader):
        X = X.to(device)
        with torch.no_grad():
            logits = model(X)  # shape (1,1,H,W)
            probs = torch.sigmoid(logits).cpu().numpy()[0, 0]  # (H,W)
            mask = (probs >= threshold).astype(np.uint8)

        # derive filename: get original image path from dataset
        # PhC keeps image_paths attribute
        img_path = testset.image_paths[idx]
        base = os.path.splitext(os.path.basename(img_path))[0]
        out_name = f"{base}_mask.png"
        out_path = os.path.join(output_dir, out_name)
        save_mask(mask, out_path)

    print(f"Saved predictions to {output_dir}")

if __name__ == '__main__':
    main()
